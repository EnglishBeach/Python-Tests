
-- --------------------------------------------------------

--
-- Структура таблицы `c_king`
--

CREATE TABLE `c_king` (
  `worker_id` int(10) UNSIGNED NOT NULL,
  `experience` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
