
-- --------------------------------------------------------

--
-- Структура таблицы `c_engeener`
--

CREATE TABLE `c_engeener` (
  `id` int(10) UNSIGNED NOT NULL,
  `profession` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
